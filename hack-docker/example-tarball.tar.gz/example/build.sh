#!/bin/sh

echo This is just an example, but it works!
echo HAPPY HAPPY JOY JOY!!
