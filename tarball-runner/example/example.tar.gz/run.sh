#!/bin/sh

echo HAPPY HAPPY JOY JOY
